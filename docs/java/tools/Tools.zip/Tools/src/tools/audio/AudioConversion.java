package tools.audio;
import static java.lang.Double.isNaN;
import static java.lang.Math.abs;
import static java.lang.Math.pow;
import static java.lang.Math.round;
import java.util.Arrays;
import java.util.OptionalDouble;
public final class AudioConversion{
	private AudioConversion(){}
	/*
	リニアPCM byte配列をdouble配列に変換する。
	
	渡すバイトデータのフォーマットを引数で指定する。
	
	例えば8bitの場合，byte値を，
	①128で割る方法
	②127で割り，クリップさせる方法
	③正のとき127，負のとき128で割る方法
	の3つがあり，ここでは①を用いる。
	歪みが無いため。
	*/
	public static double[][] linearPCMBytesToMultiChannelAudioDoubles(byte[] linearPCMBytes, int sampleSizeInBits, int channels, boolean signed, boolean bigEndian){
		int length = linearPCMBytes.length;
		int frameSizeInBytes = (sampleSizeInBits + 7) / 8 * channels;
		if(length % frameSizeInBytes != 0) throw new IllegalArgumentException("length of linearPCMBytes must be integral number of frame size");
		if(sampleSizeInBits == 8 || sampleSizeInBits == 16 || sampleSizeInBits == 24 || sampleSizeInBits == 32 || sampleSizeInBits == 40 || sampleSizeInBits == 48 || sampleSizeInBits == 56 || sampleSizeInBits == 64){
			int answerLength = length / frameSizeInBytes;
			int sampleSizeInBytes = sampleSizeInBits / 8;
			double[][] answer = new double[channels][answerLength];
			for(int t = 0;t < answerLength;t++){
				for(int c = 0;c < channels;c++){
					long temp = 0L;
					for(int b = 0;b < sampleSizeInBytes - 1;b++){
						int shift = (bigEndian ? sampleSizeInBytes - 1 - b : b) * 8;
						temp |= (linearPCMBytes[t * frameSizeInBytes + c * sampleSizeInBytes + b] << shift) & (0xFF << shift);
					}
					int b = sampleSizeInBytes - 1;
					int shift = (bigEndian ? sampleSizeInBytes - 1 - b : b) * 8;
					temp |= linearPCMBytes[t * frameSizeInBytes + c * sampleSizeInBytes + b] << shift;
					answer[c][t] = temp / pow(2.0, sampleSizeInBits - 1);
				}
			}
			return answer;
		}else throw new RuntimeException("not implemented yet");
	}
	/*
	double配列をリニアPCM byte配列に変換する。
	
	返されるバイトデータのフォーマットを引数で指定する。
	
	例えば8 bitの場合，double値に，
	①127をかける方法
	②128をかけ，クリップさせる方法
	③正のとき127，負のとき128をかける方法
	の3つがあり，ここでは①を用いる。
	歪みが無いため。
	*/
	public static byte[] multiChannelAudioDoublesToLinearPCMBytes(double[][] arrayOfAudioDoubles, int sampleSizeInBits, boolean signed, boolean bigEndian){
		int channels = arrayOfAudioDoubles.length;
		if(channels < 1) throw new IllegalArgumentException("must have at least one array");
		int length = arrayOfAudioDoubles[0].length;
		for(int i = 1;i < channels;i++) if(arrayOfAudioDoubles[i].length != length) throw new IllegalArgumentException("length mismatch");
		for(double[] ds : arrayOfAudioDoubles) for(double d : ds) if(isNaN(d)) throw new IllegalArgumentException("cannot contain NaN");
		for(double[] ds : arrayOfAudioDoubles) for(double d : ds) if(abs(d) > 1.0) throw new IllegalArgumentException("value must be within the range between -1.0 and 1.0");
		if(sampleSizeInBits == 8 || sampleSizeInBits == 16 || sampleSizeInBits == 24 || sampleSizeInBits == 32 || sampleSizeInBits == 40 || sampleSizeInBits == 48 || sampleSizeInBits == 56 || sampleSizeInBits == 64){
			int sampleSizeInBytes = sampleSizeInBits / 8;
			int frameSizeInBytes = sampleSizeInBytes * channels;
			int answerLength = Math.multiplyExact(length, frameSizeInBytes);
			byte[] answer = new byte[answerLength];
			for(int t = 0;t < length;t++){
				for(int c = 0;c < channels;c++){
					long temp = round(arrayOfAudioDoubles[c][t] * (pow(2.0, sampleSizeInBits - 1) - 1.0));
					for(int b = 0;b < sampleSizeInBytes;b++){
						if(signed){
							int shift = (bigEndian ? sampleSizeInBytes - 1 - b : b) * 8;
							answer[t * frameSizeInBytes + c * sampleSizeInBytes + b] = (byte)(temp >>> shift);
						}else throw new RuntimeException("not implemented yet");
					}
				}
			}
			return answer;
		}else throw new RuntimeException("not implemented yet");
	}
	public static byte[] monoralAudioDoublesToLinearPCMBytes(double[] audioDoubles, int sampleSizeInBits, boolean signed, boolean bigEndian){
		return multiChannelAudioDoublesToLinearPCMBytes(new double[][]{audioDoubles}, sampleSizeInBits, signed, bigEndian);
	}
	public static byte[] stereoAudioDoublesToLinearPCMBytes(double[] left, double[] right, int sampleSizeInBits, boolean signed, boolean bigEndian){
		return multiChannelAudioDoublesToLinearPCMBytes(new double[][]{left, right}, sampleSizeInBits, signed, bigEndian);
	}
	/*
	double配列を，-1.0以上1.0以下となるように正規化する。
	
	double配列の各値の絶対値の最大値がすでに1.0未満となっているとき，
	amplifiesがtrueの場合，最大値が1.0となるように増幅する。
	falseの場合，そのまま返す。
	
	doublesがnullの場合，IllegalArgumentExceptionが発生する。
	doublesがNaNや無限大を含む場合，IllegalArgumentExceptionが発生する。
	*/
	public static double[] normalize(double[] doubles, boolean amplifies){
		if(doubles == null) throw new IllegalArgumentException("doubles cannot be null");
		for(double d : doubles) if(Double.isNaN(d)) throw new IllegalArgumentException("doubles cannot contain NaN");
		for(double d : doubles) if(Double.isInfinite(d)) throw new IllegalArgumentException("doubles cannot contain infinite value");
		OptionalDouble maxAbsOptional = Arrays.stream(doubles).map(Math::abs).max();
		if(!maxAbsOptional.isPresent()) return new double[0];
		double maxAbs = maxAbsOptional.getAsDouble();
		double[] answer = doubles.clone();
		if(maxAbs == 0.0) return answer;
		if(maxAbs == 1.0) return answer;
		if(maxAbs < 1.0) if(!amplifies) return answer;
		int length = answer.length;
		for(int i = 0;i < length;i++) answer[i] /= maxAbs;
		return answer;
	}
}