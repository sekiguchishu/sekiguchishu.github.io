package tools.audio;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;
public final class AudioFiles{
	private AudioFiles(){}
	/*
	オーディオファイルにすべてのバイトを書き込む。
	*/
	public static void writeAllAudioBytes(byte[] audioBytes, AudioFormat audioFormat, AudioFileFormat.Type type, Path path){
		int length = audioBytes.length;
		int frameSize = audioFormat.getFrameSize();
		if(length % frameSize != 0) throw new IllegalArgumentException("length of audioBytes must be integral number of frame size");
		try(
				ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(audioBytes);
				//ByteArrayInputStreamはバッファリングしなくてもよい。ByteArrayInputStreamはcloseしなくてもよいので，本当は2段に分けなくてもよい。
				AudioInputStream audioInputStream = new AudioInputStream(byteArrayInputStream, audioFormat, length / frameSize);
		){
			AudioSystem.write(audioInputStream, type, path.toFile());
		}catch(IOException ex){
			throw new UncheckedIOException(null, ex);
			//AudioInputStreamのcloseは内部のInputStreamのcloseを呼ぶだけなので，closeにおいては，IOExceptionが発生することは無い。
		}
	}
	public static void writeMonoralAudioDoublesToWav(double[] audioDoubles, float sampleRate, Path path){
		byte[] bs = AudioConversion.monoralAudioDoublesToLinearPCMBytes(audioDoubles, 16, true, false);
		writeAllAudioBytes(bs, new AudioFormat(sampleRate, 16, 1, true, false), AudioFileFormat.Type.WAVE, path);
	}
	public static void writeMonoralAudioDoublesToWav(double[] audioDoubles, double sampleRate, Path path){
		writeMonoralAudioDoublesToWav(audioDoubles, (float)sampleRate, path);
	}
	public static void writeStereoAudioDoublesToWav(double[] left, double[] right, float sampleRate, Path path){
		byte[] bs = AudioConversion.multiChannelAudioDoublesToLinearPCMBytes(new double[][]{left, right}, 16, true, false);
		writeAllAudioBytes(bs, new AudioFormat(sampleRate, 16, 2, true, false), AudioFileFormat.Type.WAVE, path);
	}
	public static void writeStereoAudioDoublesToWav(double[] left, double[] right, double sampleRate, Path path){
		writeStereoAudioDoublesToWav(left, right, (float)sampleRate, path);
	}
	/*
	オーディオファイルからすべてのバイトを読み取る。
	*/
	public static byte[] readAllAudioBytes(Path path){
		try(AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(path.toFile())){
			int length = audioInputStream.available();
			byte[] answer = new byte[length];
			int read = audioInputStream.read(answer);
			if(read != length) throw new AssertionError();
			return answer;
		}catch(UnsupportedAudioFileException ex){
			throw new RuntimeException(null, ex);
		}catch(IOException ex){
			throw new UncheckedIOException(null, ex);
		}
	}
	public static AudioFileFormat getAudioFileFormat(Path path){
		try{
			return AudioSystem.getAudioFileFormat(path.toFile());
		}catch(UnsupportedAudioFileException ex){
			throw new RuntimeException(null, ex);
		}catch(IOException ex){
			throw new UncheckedIOException(null, ex);
		}
	}
	public static AudioFormat getAudioFormat(Path path){
		return getAudioFileFormat(path).getFormat();
	}
	public static double[] getMonoralAudioDoubles(Path path){
		byte[] audioBytes = readAllAudioBytes(path);
		AudioFormat audioFormat = getAudioFormat(path);
		int sampleSizeInBits = audioFormat.getSampleSizeInBits();
		int channels = audioFormat.getChannels();
		boolean signed = audioFormat.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED);
		boolean bigEndian = audioFormat.isBigEndian();
		double[][] answerMulti = AudioConversion.linearPCMBytesToMultiChannelAudioDoubles(audioBytes, sampleSizeInBits, channels, signed, bigEndian);
		double[] answer = new double[answerMulti[0].length];
		for(int i = 0;i < answer.length;i++){
			double sum = 0.0;
			for(int c = 0;c < channels;c++) sum += answerMulti[c][i];
			answer[i] = sum / channels;
		}
		return answer;
	}
	public static double[][] getStereoAudioDoubles(Path path){
		byte[] audioBytes = readAllAudioBytes(path);
		AudioFormat audioFormat = getAudioFormat(path);
		if(audioFormat.getChannels() != 2) throw new IllegalArgumentException("channels must be 2");
		int sampleSizeInBits = audioFormat.getSampleSizeInBits();
		boolean signed = audioFormat.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED);
		boolean bigEndian = audioFormat.isBigEndian();
		return AudioConversion.linearPCMBytesToMultiChannelAudioDoubles(audioBytes, sampleSizeInBits, 2, signed, bigEndian);
	}
}