package tools.audio;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
public final class AudioPlayback{
	private AudioPlayback(){}
	/*
	byte配列を指定したフォーマットで解釈し，音として出力する。
	
	audioBytesに再生するデータを渡す。
	audioBytesの要素の値は書き換えてはいけない。
	
	audioFormatにbyte配列を解釈するフォーマットを渡す。
	
	audioBytesまたはaudioFormatがnullであった場合，IllegalArgumentExceptionが発生する。
	audioBytesの長さがフレームサイズの整数倍でない場合，IllegalArgumentExceptionが発生する。
	
	再生するためのSourceDataLineを取得，オープンできなかった場合，audioFormatが不正であった場合，
	音は再生されず，返り値のFutureへのget()でExecutionExceptionが発生する。
	
	音の再生が始まると，このメソッドはすぐに返る。
	返り値のFutureへのget()は，音の再生が終わるまで待機し，常にnullを返す。
	cancel(true)は，音の再生を中断する。
	cancelが呼ばれると，基本的にすぐ音の再生は終了するが，
	データの終わりに近いタイミングでのcancel(drain()中のcancel)のinterruptは無視され，最後まで音が再生される。
	*/
	public static Future<?> playbackAudioBytesCancellable(byte[] audioBytes, AudioFormat audioFormat){
		if(audioBytes == null) throw new IllegalArgumentException("audioBytes cannot be null");
		if(audioFormat == null) throw new IllegalArgumentException("audioFormat cannot be null");
		int length = audioBytes.length;
		int frameSize = audioFormat.getFrameSize();
		if(length % frameSize != 0) throw new IllegalArgumentException("length of audioBytes must be integral number of frame size");
		Object interruptLockObject = new Object();
		Callable<?> callable = () -> {
			if(Thread.interrupted()) throw new InterruptedException();
			try(SourceDataLine sourceDataLine = AudioSystem.getSourceDataLine(audioFormat)){
				sourceDataLine.open(audioFormat);
				sourceDataLine.start();
				int bufferSize = sourceDataLine.getBufferSize();
				long frameRate = (long)Math.ceil(audioFormat.getFrameRate());
				for(int written = 0;written < length;){
					try{
						int remainingBytes = bufferSize - sourceDataLine.available();
						long sleepTimeInMilliseconds = remainingBytes / frameSize * 1000L / frameRate;
						sleepTimeInMilliseconds = Math.max(sleepTimeInMilliseconds - 100L, 0L);
						Thread.sleep(sleepTimeInMilliseconds);
					}catch(InterruptedException ex){
						sourceDataLine.stop();
						sourceDataLine.flush();
						throw ex;
					}
					synchronized(interruptLockObject){
						if(Thread.interrupted()){
							sourceDataLine.stop();
							sourceDataLine.flush();
							throw new InterruptedException();
						}
						int writeSize = Math.min(sourceDataLine.available(), length - written);
						written += sourceDataLine.write(audioBytes, written, writeSize);
					}
				}
				sourceDataLine.drain();
				sourceDataLine.stop();
				sourceDataLine.flush();
			}
			return null;
		};
		FutureTask<?> futureTask = new FutureTask<>(callable);
		Thread thread = new Thread(){
			@Override
			public void interrupt(){
				synchronized(interruptLockObject){
					super.interrupt();
				}
			}
			@Override
			public void run(){
				futureTask.run();
			}
		};
		thread.start();
		return futureTask;
	}
	public static Future<?> playbackMonoralAudioDoublesCancellable(double[] audioDoubles, float sampleRate){
		byte[] bs = AudioConversion.monoralAudioDoublesToLinearPCMBytes(audioDoubles, 16, true, false);
		AudioFormat audioFormat = new AudioFormat(sampleRate, 16, 1, true, false);
		return playbackAudioBytesCancellable(bs, audioFormat);
	}
	public static Future<?> playbackMonoralAudioDoublesCancellable(double[] audioDoubles, double sampleRate){
		return playbackMonoralAudioDoublesCancellable(audioDoubles, (float)sampleRate);
	}
	/*
	byte配列を指定したフォーマットで解釈し，音として出力する。
	
	audioBytesに再生するデータを渡す。
	audioBytesの要素の値は書き換えてはいけない。
	
	audioFormatにbyte配列を解釈するフォーマットを渡す。
	
	audioBytesまたはaudioFormatがnullであった場合，IllegalArgumentExceptionが発生する。
	audioBytesの長さがフレームサイズの整数倍でない場合，IllegalArgumentExceptionが発生する。
	
	再生するためのSourceDataLineを取得，オープンできなかった場合，audioFormatが不正であった場合，
	音は再生されず，バックグラウンドのスレッドがRuntimeExceptionを投げて終了する。
	
	音の再生が始まると，このメソッドはすぐに返る。
	音を最後まで再生するユーザースレッドが作成される。
	このスレッドへのinterruptは，無視される。
	音の再生が終わるまで待機する方法はない。
	音の再生を中断する方法もない。
	*/
	public static void playbackAudioBytes(byte[] audioBytes, AudioFormat audioFormat){
		if(audioBytes == null) throw new IllegalArgumentException("audioBytes cannot be null");
		if(audioFormat == null) throw new IllegalArgumentException("audioFormat cannot be null");
		if(audioBytes.length % audioFormat.getFrameSize() != 0) throw new IllegalArgumentException("length of audioBytes must be integral number of frame size");
		Thread thread = new Thread(() -> {
			try(SourceDataLine sourceDataLine = AudioSystem.getSourceDataLine(audioFormat)){
				sourceDataLine.open(audioFormat);
				sourceDataLine.start();
				sourceDataLine.write(audioBytes, 0, audioBytes.length);
				sourceDataLine.drain();
				sourceDataLine.stop();
				sourceDataLine.flush();
			}catch(LineUnavailableException ex){
				throw new RuntimeException(null, ex);
			}
		});
		thread.start();
	}
	public static void playbackMonoralAudioDoubles(double[] audioDoubles, float sampleRate){
		byte[] bs = AudioConversion.monoralAudioDoublesToLinearPCMBytes(audioDoubles, 16, true, false);
		AudioFormat audioFormat = new AudioFormat(sampleRate, 16, 1, true, false);
		playbackAudioBytes(bs, audioFormat);
	}
	public static void playbackMonoralAudioDoubles(double[] audioDoubles, double sampleRate){
		playbackMonoralAudioDoubles(audioDoubles, (float)sampleRate);
	}
}