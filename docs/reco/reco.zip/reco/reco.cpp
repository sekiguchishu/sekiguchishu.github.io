/*
    【はじめに】

    プログラムについてわからないことがあるとき，
    最も良い解決方法は，作った本人に聞くことです。
    このコードに関して質問がある場合，
    関口 周（せきぐち しゅう）
    Twitter：@sekiguchi_shu
    まで遠慮なくDMをください。
    僕と個人的に知り合いの方は，
    ラインなどで直接コンタクトしてください。
*/


/*
    【論文】

    このソースコードで用いているアルゴリズムは，
    以下の論文を参考にしたものです。
    タイトル：Efficient Convolution without Input-Output Delay
    著者：William G. Gardner
    URL：http://www.cs.ust.hk/mjg_lib/bibs/DPSu/DPSu.Files/Ga95.PDF
*/


/*
    【前提知識】

    オーディオデータを，数十～数百サンプルごとに区切って扱います。
    そのひと区切りを「フレーム」とよびます。
    ところで，同じ時刻の「サンプル」を「チャンネル数」ぶんまとめたものも，
    一般に「フレーム」とよばれます。
    この「フレーム」の2つの用法については，文脈で判断してください。

    論文を読めばわかりますが，
    N = frameLengthとしたとき，
    インパルス応答を，
    2N, N, N, 2N, 2N, 4N, 4N, 8N, 8N, 16N, 16N, 32N, 32N, 64N, ...
    の長さに区切って計算します。
    そのひと区切りを「ブロック」とよびます。
*/


/*
    【プログラムの構造】

    PortAudioのコールバックと
    自分で作った数本のスレッドが
    InputBufferとOutputBufferを介してやり取りするという構造です。
    コールバックには，マイクからの入力が入ってきます。
    コールバックは，それを，InputBufferに書き込みます。
    スレッドは，
    ブロック0に対して1本，
    ブロック1,2に対して1本，
    ブロック3,4に対して1本， ...
    という具合です。
    ただし，全ブロック数が偶数の場合，
    最後のスレッドが担当するのはブロック1つです。
    各スレッドは，InputBufferから入力が利用可能になるまで待機します。
    利用可能になったら，畳み込みを計算し，
    OutputBufferに書き込みます。
    コールバックは，OutputBufferから出力が利用可能になるまで待機します。
    利用可能になったら，スピーカーに出力します。
*/


/*
    【依存ライブラリ】

    このコードは，
    ・Intel MKL
    ・PortAudio
    ・dr_wav
    に依存しています。
*/


/*
    【コンパイル方法】

    コンパイルして実行するには，
    同梱しているバッチファイルを実行すればよいでしょう。
    自分の環境に合わせて改変してください。
*/


#include "mkl.h"
#include "pa_include/portaudio.h"
#include "pa_include/pa_asio.h" // Windowsの場合
#include "pa_include/pa_mac_core.h" // Macの場合
#define DR_WAV_IMPLEMENTATION
#include "dr_wav.h"

#include <stdexcept>
#include <iostream>
#include <mutex>
#include <condition_variable>
#include <cstring>
#include <vector>
#include <thread>


namespace{ // 無名名前空間


/*
％演算子は，
-1 ％ 5
をしたときに-1が返るが，
4が返るようにしたい。
そうすれば，負の数を含めても，
0, 1, 2, 3, 4, 0, 1, 2, 3, 4, 0, 1, 2, 3, 4, ...
となる。
ただしbは正であることを想定している。
*/
constexpr int floorMod(int a, int b){
    return (a % b + b) % b;
}


/*
引数のlog2をとり，
それを切り上げた値を返す。
0以下の値が渡されることは想定していない。
*/
constexpr int ceilLog2(int x){
    int counter = 0; // x-1を2進数で表したときの桁数を数える。
    int xx = x - 1;
    while(xx != 0){ // 正の整数なので右シフトしていくといずれ0になる。そのシフト回数を数える。
        xx >>= 1;
        counter++;
    }
    return counter;
}


/*
分割されたIRブロックの中にフレームが何個入るかを返す関数。

 0 ->  2
 1 ->  1
 2 ->  1
 3 ->  2
 4 ->  2
 5 ->  4
 6 ->  4
 7 ->  8
 8 ->  8
 9 -> 16
10 -> 16
...

を返す。
*/
constexpr int getNumberOfFramesInBlock(int blockNumber){
    if(blockNumber <= 0) return 2;
    int x = (blockNumber - 1) / 2; // 答えが2の何乗かを計算する。
    return 1 << x; // 2のx乗。
}


/*
IR長とフレーム長からIRの分割数を決める。
以下に，フレーム長を1とした場合の，
関数中の各値を示す。
これを見れば法則が分かる。

IR   a   b   c   d   e  ans
 1   *   *   *   *   *   1
 2   *   *   *   *   *   1
 3   1   2   0   0   0   2
 4   2   2   0   1   1   3
 5   3   3   1   0   0   4
 6   4   3   1   1   0   4
 7   5   4   1   2   1   5
 8   6   4   1   3   1   5
 9   7   5   2   0   0   6
10   8   5   2   1   0   6
11   9   6   2   2   0   6
12  10   6   2   3   0   6
13  11   7   2   4   1   7
14  12   7   2   5   1   7
15  13   8   2   6   1   7
16  14   8   2   7   1   7
17  15   9   3   0   0   8
18  16   9   3   1   0   8
19  17  10   3   2   0   8
20  18  10   3   3   0   8
21  19  11   3   4   0   8
22  20  11   3   5   0   8
23  21  12   3   6   0   8
24  22  12   3   7   0   8
25  23  13   3   8   1   9
26  24  13   3   9   1   9
27  25  14   3  10   1   9
28  26  14   3  11   1   9
29  27  15   3  12   1   9
30  28  15   3  13   1   9
31  29  16   3  14   1   9
32  30  16   3  15   1   9
33  31  17   4   0   0  10
...
*/
constexpr int fromIRLengthAndFrameLengthToNumberOfBlocksInIR(int irLength, int frameLength){
    int n = frameLength;
    if(irLength <= 2 * n) return 1;
    int a = irLength - 2 * n;
    int b = (a + 2 * n - 1) / (2 * n) + 1;
    int c = ceilLog2(b) - 1;
    int d = a - ((1 << c) - 1) * 2 * n - 1; // 1<<c は2のc乗
    int e = d / (n * (1 << c));
    return c * 2 + e + 2;
}


/*
複素数配列aとbの要素ごとの掛け算を計算してansに格納する。
*/
void elementwiseTimes(int n, const float* aRe, const float* aIm, const float* bRe, const float* bIm, float* ansRe, float* ansIm){
    for(int i = 0;i < n;i++){
        ansRe[i] = aRe[i] * bRe[i] - aIm[i] * bIm[i];
        ansIm[i] = aRe[i] * bIm[i] + aIm[i] * bRe[i];
    }
}


/*
FFT関連。
ディスクリプターを作る。
*/
void createDescriptor(DFTI_DESCRIPTOR_HANDLE* descriptor, int fftLength){
    DftiCreateDescriptor(descriptor, DFTI_SINGLE, DFTI_COMPLEX, 1, fftLength);
    DftiSetValue(*descriptor, DFTI_PLACEMENT, DFTI_NOT_INPLACE);
    DftiSetValue(*descriptor, DFTI_COMPLEX_STORAGE, DFTI_REAL_REAL);
    DftiSetValue(*descriptor, DFTI_BACKWARD_SCALE, 1.0 / fftLength);
    DftiCommitDescriptor(*descriptor);
}


/*
FFT関連。
ディスクリプターを解放する。
*/
void freeDescriptor(DFTI_DESCRIPTOR_HANDLE* descriptor){
    DftiFreeDescriptor(descriptor);
}


/*
PortAudio関連。
*/
void checkError(PaError err){
    if(err != paNoError){
        Pa_Terminate();
        throw std::runtime_error(Pa_GetErrorText(err));
    }
}


/*
PortAudio関連。
*/
void printDeviceInfos(){
    PaError err = Pa_Initialize();
    checkError(err);
    int deviceCount = Pa_GetDeviceCount();
    for(int i = 0;i < deviceCount;i++){
        const PaDeviceInfo* info = Pa_GetDeviceInfo(i);
        std::cout << "[" << i << "]" << std::endl;
        std::cout << info->name << std::endl;
        std::cout << "I/O max channels : " << info->maxInputChannels << " / " << info->maxOutputChannels << "\n" << std::endl;
    }
    Pa_Terminate();
}


/*
PortAudio関連。
*/
PaStream* createNewPaStream(
        int deviceID,
        int* inputChannelSelector,
        int outputNumberOfChannels,
        int* outputChannelSelector,
        int sampleRate,
        int framesPerBuffer,
        PaStreamCallback paStreamCallback,
        void* userData
){
    PaError err = Pa_Initialize();
    checkError(err);
    PaMacCoreStreamInfo inputAsioInfo; // Windowsの場合はここを「PaAsioStreamInfo」に変える必要がある。
    inputAsioInfo.size = sizeof(PaMacCoreStreamInfo);
    inputAsioInfo.hostApiType = paCoreAudio;
    inputAsioInfo.version = 1;
    inputAsioInfo.flags = paAsioUseChannelSelectors;
    inputAsioInfo.channelMap = inputChannelSelector;
    inputAsioInfo.channelMapSize = 1;
    PaStreamParameters inputParameters;
    inputParameters.device = deviceID;
    inputParameters.channelCount = 1;
    inputParameters.sampleFormat = paFloat32;
    inputParameters.suggestedLatency = Pa_GetDeviceInfo(deviceID)->defaultLowInputLatency;
    inputParameters.hostApiSpecificStreamInfo = &inputAsioInfo;
    PaMacCoreStreamInfo outputAsioInfo; // Windowsの場合はここを「PaAsioStreamInfo」に変える必要がある。
    outputAsioInfo.size = sizeof(PaMacCoreStreamInfo);
    outputAsioInfo.hostApiType = paCoreAudio;
    outputAsioInfo.version = 1;
    outputAsioInfo.flags = paAsioUseChannelSelectors;
    outputAsioInfo.channelMap = outputChannelSelector;
    outputAsioInfo.channelMapSize = outputNumberOfChannels;
    PaStreamParameters outputParameters;
    outputParameters.device = deviceID;
    outputParameters.channelCount = outputNumberOfChannels;
    outputParameters.sampleFormat = paFloat32;
    outputParameters.suggestedLatency = Pa_GetDeviceInfo(deviceID)->defaultLowOutputLatency;
    outputParameters.hostApiSpecificStreamInfo = &outputAsioInfo;
    PaStream* answer;
    err = Pa_OpenStream(&answer, &inputParameters, &outputParameters, sampleRate, framesPerBuffer, paNoFlag, paStreamCallback, userData);
    checkError(err);
    return answer;
}


/*
PortAudio関連。
*/
void start(PaStream* stream){
    PaError err = Pa_StartStream(stream);
    checkError(err);
}


/*
PortAudio関連。
*/
void close(PaStream* stream){
    PaError err = Pa_StopStream(stream);
    checkError(err);
    err = Pa_CloseStream(stream);
    checkError(err);
    Pa_Terminate();
}


class AbortException : std::exception{};


/*
マイクからの入力をためておくためのバッファー。
あるIRブロックとの畳み込みでは
過去の入力フレームも必要になるので
ためておく必要がある。
バッファーの実装はリングバッファーである。
読み出しを高速にするため，
二重で保存している。
たとえばバッファーが[1, 2, 3, 4]であって，
インデックス2を起点として4つぶん読み出そうとすると，
結果は[3, 4, 1, 2]にならなければならないので，
剰余計算が必要になる
（インデックス2,3,4,5とアクセスすると，
4と5が配列の最大インデックスを超えるので
％4を計算して，2,3,0,1とアクセスしなければならない）。
しかしバッファーへの書き込みの際に二重で書き込んでおく，
すなわち，
[1, 2, 3, 4, 1, 2, 3, 4]
のように保存しておけば，
インデックス2から5までを読み出すだけでよい。
*/
class InputBuffer{
private:
    std::mutex mut;
    std::condition_variable cond;
    bool isAborted;
    int counter; // バッファー内での現在の読み書き位置
    int frameNumberCounterFromOrigin; // 通しフレーム番号を数える
    int frameLength;
    int numberOfFramesInBuffer; // バッファーサイズ
    int bufferLengthInSample; // バッファーのサンプル長さ。実際はこれの2倍である。
    float* array;
public:
    InputBuffer(int frameLength, int numberOfFramesInBuffer):
            isAborted(false),
            counter(0),
            frameNumberCounterFromOrigin(-1),
            frameLength(frameLength),
            numberOfFramesInBuffer(numberOfFramesInBuffer),
            bufferLengthInSample(frameLength * numberOfFramesInBuffer)
    {
        array = new float[bufferLengthInSample * 2]();
    }
    ~InputBuffer(){
        delete array;
    }
    void writeFrame(float* frame) noexcept(false){
        std::unique_lock<std::mutex> lock(mut); // 他スレッドと同期
        if(isAborted) throw AbortException(); // 中断を確認
        int from = counter * frameLength; // 書き込みインデックスを取得
        std::memcpy(array + from, frame, frameLength * sizeof(float));
        std::memcpy(array + (from + bufferLengthInSample), frame, frameLength * sizeof(float)); // 2重で保存
        counter = (counter + 1) % numberOfFramesInBuffer; // カウンターを回す（リングバッファーなので％を使う）
        frameNumberCounterFromOrigin++;
        cond.notify_all(); // マイクからの入力を待機しているスレッドを起こす
    }
    float* getReadPosition(int frameNumberFromOrigin, int numberOfFramesToRead) noexcept(false){
        std::unique_lock<std::mutex> lock(mut);
        while(!isAborted && (frameNumberFromOrigin + numberOfFramesToRead - 1 > frameNumberCounterFromOrigin)){
            cond.wait(lock); // まだ，読み出したいフレームが準備できていなければ待機
        }
        if(isAborted) throw AbortException();
        int indexStart = floorMod(counter - 1 + frameNumberFromOrigin - frameNumberCounterFromOrigin, numberOfFramesInBuffer) * frameLength; // 読み出しインデックスを取得
        return array + indexStart;
    }
    void abort(){ // これのよび出し以降，writeおよびreadでAbortExceptionが投げられる
        std::lock_guard<std::mutex> lock(mut);
        isAborted = true;
        cond.notify_all();
    }
};


/*
計算結果をためておくためのバッファー。
読み書きはキュー形式である。
*/
class OutputBuffer{
private:
    std::mutex mut;
    std::condition_variable cond;
    bool isAborted;
    int* front; // キューの先頭位置（モジュロは取らずにカウントしていく）
    int back; // キューの末尾位置（モジュロは取らずにカウントしていく）
    float* array;
    int queueCapacity;
    int maxNf;
    int frameLength;
    int numberOfOutputChannels;
    int numberOfBlocksInIR;
public:
    OutputBuffer(int frameLength, int numberOfOutputChannels, int numberOfBlocksInIR):
            isAborted(false),
            back(-1),
            queueCapacity(8),
            maxNf(getNumberOfFramesInBlock(std::max(3, numberOfBlocksInIR - 1))),
            frameLength(frameLength),
            numberOfOutputChannels(numberOfOutputChannels),
            numberOfBlocksInIR(numberOfBlocksInIR)
    {
        front = new int[numberOfBlocksInIR];
        front[0] = -1;
        for(int b = 1;b < numberOfBlocksInIR;b++){
            int nf = getNumberOfFramesInBlock(b);
            if(b % 2 == 1){
                front[b] = 2 * nf - 1;
            }else{
                front[b] = 3 * nf - 1;
            }
        }
        array = new float[queueCapacity * frameLength * numberOfOutputChannels * maxNf]();
    }
    ~OutputBuffer(){
        delete array;
        delete front;
    }
    void writeBlock(int blockNumber, float* conv) noexcept(false){
        std::unique_lock<std::mutex> lock(mut);
        if(isAborted) throw AbortException();
        int b = blockNumber;
        int nf = getNumberOfFramesInBlock(b);
        bool wasEmpty = (front[b] - back == 0);
        int writeFramePosition = (front[b] + 1) % (queueCapacity * maxNf);
        int writePosition = writeFramePosition * frameLength * numberOfOutputChannels;
        for(int f = 0;f < nf;f++){
            for(int i = 0;i < frameLength;i++){
                for(int c = 0;c < numberOfOutputChannels;c++){
                    (array + writePosition)[f * frameLength * numberOfOutputChannels + i * numberOfOutputChannels + c] += conv[frameLength * nf * 2 * c + frameLength * f + i];
                }
            }
        }
        front[b] += nf;
        if(wasEmpty) cond.notify_one();
    }
    bool isEmpty(){
        for(int b = 0;b < numberOfBlocksInIR;b++){
            if(front[b] - back == 0) return true;
        }
        return false;
    }
    void copyToAnswer(int frameNumberFromOrigin, float* answer) noexcept(false){
        std::unique_lock<std::mutex> lock(mut);
        while(!isAborted && isEmpty()){
            // 計算の遅れを確認するには，このコメントアウトをはずす
            //std::cout << "late : frameNumber = " << frameNumberFromOrigin << std::endl;
            cond.wait(lock);
        }
        if(isAborted) throw AbortException();
        if(frameNumberFromOrigin - 1 == back) back++;
        int readFramePosition = floorMod(frameNumberFromOrigin, queueCapacity * maxNf);
        int readPosition = readFramePosition * frameLength * numberOfOutputChannels;
        std::memcpy(answer, array + readPosition, sizeof(float) * frameLength * numberOfOutputChannels);
        std::memset(array + readPosition, 0, sizeof(float) * frameLength * numberOfOutputChannels);
    }
    void abort(){
        std::lock_guard<std::mutex> lock(mut);
        isAborted = true;
        cond.notify_all();
    }
};


void thread0(InputBuffer* inputBuffer, OutputBuffer* outputBuffer, int numberOfOutputChannels, int frameLength, float** splitFFTedIRs, int threadNumber){
    constexpr int b = 0;
    constexpr int nf = getNumberOfFramesInBlock(b);
    int fftLength = frameLength * nf * 2;
    DFTI_DESCRIPTOR_HANDLE descriptor;
    createDescriptor(&descriptor, fftLength);
    float* zeros = new float[fftLength]();
    float* xFFT = new float[fftLength * 2];
    float* times = new float[fftLength * 2 * numberOfOutputChannels];
    float* dummy = new float[fftLength];
    float* conv = new float[fftLength * numberOfOutputChannels];
    for(int start = -nf;true;start += nf){
        try{
            float* xBlock = inputBuffer->getReadPosition(start - nf, nf * 2);
            DftiComputeForward(descriptor, xBlock, zeros, xFFT, xFFT + fftLength);
            for(int c = 0;c < numberOfOutputChannels;c++){
                elementwiseTimes(
                        fftLength,
                        xFFT,
                        xFFT + fftLength,
                        splitFFTedIRs[b] + (fftLength * 2 * c),
                        splitFFTedIRs[b] + (fftLength * 2 * c + fftLength),
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength)
                );
                DftiComputeBackward(
                        descriptor,
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength),
                        conv + (fftLength * c),
                        dummy
                );
            }
            outputBuffer->writeBlock(b, conv);
        }catch(AbortException& ex){
            break;
        }
    }
    delete conv;
    delete dummy;
    delete times;
    delete xFFT;
    delete zeros;
    freeDescriptor(&descriptor);
}


void threadi(InputBuffer* inputBuffer, OutputBuffer* outputBuffer, int numberOfOutputChannels, int frameLength, float** splitFFTedIRs, int threadNumber){
    int b1 = threadNumber * 2;
    int b0 = b1 - 1;
    int nf = getNumberOfFramesInBlock(b0);
    int fftLength = frameLength * nf * 2;
    DFTI_DESCRIPTOR_HANDLE descriptor;
    createDescriptor(&descriptor, fftLength);
    float* zeros = new float[fftLength]();
    float* xFFT = new float[fftLength * 2];
    float* times = new float[fftLength * 2 * numberOfOutputChannels];
    float* dummy = new float[fftLength];
    float* conv = new float[fftLength * numberOfOutputChannels];
    for(int start = -nf;true;start += nf){
        try{
            float* xBlock = inputBuffer->getReadPosition(start - nf, nf * 2);
            DftiComputeForward(descriptor, xBlock, zeros, xFFT, xFFT + fftLength);
            for(int c = 0;c < numberOfOutputChannels;c++){
                elementwiseTimes(
                        fftLength,
                        xFFT,
                        xFFT + fftLength,
                        splitFFTedIRs[b0] + (fftLength * 2 * c),
                        splitFFTedIRs[b0] + (fftLength * 2 * c + fftLength),
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength)
                );
                DftiComputeBackward(
                        descriptor,
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength),
                        conv + (fftLength * c),
                        dummy
                );
            }
            outputBuffer->writeBlock(b0, conv);
            for(int c = 0;c < numberOfOutputChannels;c++){
                elementwiseTimes(
                        fftLength,
                        xFFT,
                        xFFT + fftLength,
                        splitFFTedIRs[b1] + (fftLength * 2 * c),
                        splitFFTedIRs[b1] + (fftLength * 2 * c + fftLength),
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength)
                );
                DftiComputeBackward(
                        descriptor,
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength),
                        conv + (fftLength * c),
                        dummy
                );
            }
            outputBuffer->writeBlock(b1, conv);
        }catch(AbortException& ex){
            break;
        }
    }
    delete conv;
    delete dummy;
    delete times;
    delete xFFT;
    delete zeros;
    freeDescriptor(&descriptor);
}


void threadLastHalf(InputBuffer* inputBuffer, OutputBuffer* outputBuffer, int numberOfOutputChannels, int frameLength, float** splitFFTedIRs, int threadNumber){
    int b0 = threadNumber * 2 - 1;
    int nf = getNumberOfFramesInBlock(b0);
    int fftLength = frameLength * nf * 2;
    DFTI_DESCRIPTOR_HANDLE descriptor;
    createDescriptor(&descriptor, fftLength);
    float* zeros = new float[fftLength]();
    float* xFFT = new float[fftLength * 2];
    float* times = new float[fftLength * 2 * numberOfOutputChannels];
    float* dummy = new float[fftLength];
    float* conv = new float[fftLength * numberOfOutputChannels];
    for(int start = -nf;true;start += nf){
        try{
            float* xBlock = inputBuffer->getReadPosition(start - nf, nf * 2);
            DftiComputeForward(descriptor, xBlock, zeros, xFFT, xFFT + fftLength);
            for(int c = 0;c < numberOfOutputChannels;c++){
                elementwiseTimes(
                        fftLength,
                        xFFT,
                        xFFT + fftLength,
                        splitFFTedIRs[b0] + (fftLength * 2 * c),
                        splitFFTedIRs[b0] + (fftLength * 2 * c + fftLength),
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength)
                );
                DftiComputeBackward(
                        descriptor,
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength),
                        conv,
                        dummy
                );
                outputBuffer->writeBlock(b0, conv);
            }
        }catch(AbortException& ex){
            break;
        }
    }
    delete conv;
    delete dummy;
    delete times;
    delete xFFT;
    delete zeros;
    freeDescriptor(&descriptor);
}


typedef struct{
    InputBuffer* inputBuffer;
    OutputBuffer* outputBuffer;
    int iy; // 出力の通しフレーム番号
} CallbackArgs;


int recoCallback(
        const void* inputBufferCallback,
        void* outputBufferCallback,
        unsigned long framesLength,
        const PaStreamCallbackTimeInfo* timeInfo,
        PaStreamCallbackFlags statusFlags,
        void* userData
){
    CallbackArgs* ca = (CallbackArgs*)userData;
    InputBuffer* inputBuffer = ca->inputBuffer;
    OutputBuffer* outputBuffer = ca->outputBuffer;
    try{
        inputBuffer->writeFrame((float*)inputBufferCallback);
        outputBuffer->copyToAnswer(ca->iy, (float*)outputBufferCallback);
    }catch(AbortException& ex){
        return PaStreamCallbackResult::paAbort;
    }
    (ca->iy)++;
    return PaStreamCallbackResult::paContinue;
}


/*
まずインパルス応答を
2N, N, N, 2N, 2N, 4N, 4N, 8N, 8N, 16N, 16N, ...
のように区切る。
インパルス応答が最後のブロックの最後まで満たなかった場合，
0が付加される。
次に，
各ブロックの先頭にブロック長と同じ長さだけ0を付加（ブロック長は2倍となる）し，
それらをFFTする。
frameLengthは2のべき乗でなければならない。
*/
void splitIRAndFFT(
        int numberOfOutputChannels,
        int irLength,
        float** ir, // 出力チャンネル分のIR
        int frameLength,
        float*** answer
){
    int numberOfBlocks = fromIRLengthAndFrameLengthToNumberOfBlocksInIR(irLength, frameLength);
    int cumsum = 0;
    *answer = new float*[numberOfBlocks];
    for(int b = 0;b < numberOfBlocks;b++){
        int blockLength = getNumberOfFramesInBlock(b) * frameLength;
        int fftLength = blockLength * 2;
        float* fft = new float[fftLength * 2 * numberOfOutputChannels]();
        for(int c = 0;c < numberOfOutputChannels;c++){
            float* temp = new float[fftLength]();
            std::memcpy(temp + blockLength, ir[c] + cumsum, sizeof(float) * std::min(blockLength, irLength - cumsum));
            float* zeros = new float[fftLength]();
            DFTI_DESCRIPTOR_HANDLE descriptor;
            createDescriptor(&descriptor, fftLength);
            DftiComputeForward(descriptor, temp, zeros, fft + (fftLength * 2 * c), fft + (fftLength * 2 * c + fftLength));
            freeDescriptor(&descriptor);
            delete zeros;
            delete temp;
        }
        (*answer)[b] = fft;
        cumsum += blockLength;
    }
}


} // namespace end


int main(){
    constexpr float outputGain = 0.05;
    constexpr int frameLength = 32;
    constexpr int delay = 0;
    constexpr int deviceNumber = 2;
    constexpr int numberOfOutputChannels = 24;
    int* inputChannelSelector = new int[1];
    inputChannelSelector[0] = 0;
    int* outputChannelSelector = new int[numberOfOutputChannels];
    for(int i = 0;i < numberOfOutputChannels;i++){
        outputChannelSelector[i] = i + 4;
    }
    constexpr int sampleRate = 48000;
    drwav wav;
    int err = drwav_init_file(&wav, "/Users/shu/Desktop/reco/IR.wav", nullptr);
    if(err == 0) throw std::runtime_error("drwav error");
    if(wav.channels != 1) throw std::runtime_error("must be one channel");
    int irLength = wav.totalPCMFrameCount;
    float* ir = new float[irLength];
    drwav_read_pcm_frames_f32(&wav, irLength, ir);
    float* pulse = new float[irLength]();
    pulse[0] = 1.0;
    for(int i = 0;i < irLength;i++) ir[i] *= outputGain;
    int numberOfBlocks = fromIRLengthAndFrameLengthToNumberOfBlocksInIR(irLength, frameLength);
    float** irs = new float*[numberOfOutputChannels];
    for(int i = 0;i < numberOfOutputChannels;i++) irs[i] = ir;
    float** splitFFTedIRs;
    splitIRAndFFT(numberOfOutputChannels, irLength, irs, frameLength, &splitFFTedIRs);
    delete ir;
    delete pulse;
    delete irs;
    printDeviceInfos();
    int bMax = std::max(3, numberOfBlocks - 1);
    int nfMax = getNumberOfFramesInBlock(bMax);
    InputBuffer inputBuffer(frameLength, nfMax * 2);
    OutputBuffer outputBuffer(frameLength, numberOfOutputChannels, numberOfBlocks);
    int numberOfThreads = numberOfBlocks / 2 + 1;
    std::thread t0(thread0, &inputBuffer, &outputBuffer, numberOfOutputChannels, frameLength, splitFFTedIRs, 0);
    t0.detach();
    for(int i = 1;i < numberOfThreads - 1;i++){
        std::thread ti(threadi, &inputBuffer, &outputBuffer, numberOfOutputChannels, frameLength, splitFFTedIRs, i);
        ti.detach();
    }
    if(numberOfThreads >= 2){
        if(numberOfBlocks % 2 == 0){
            std::thread tl(threadLastHalf, &inputBuffer, &outputBuffer, numberOfOutputChannels, frameLength, splitFFTedIRs, numberOfThreads - 1);
            tl.detach();
        }else{
            std::thread tl(threadi, &inputBuffer, &outputBuffer, numberOfOutputChannels, frameLength, splitFFTedIRs, numberOfThreads - 1);
            tl.detach();
        }
    }
    CallbackArgs ca;
    ca.inputBuffer = &inputBuffer;
    ca.outputBuffer = &outputBuffer;
    ca.iy = -delay;
    PaStream* stream = createNewPaStream(deviceNumber, inputChannelSelector, numberOfOutputChannels, outputChannelSelector, sampleRate, frameLength, recoCallback, &ca);
    start(stream);
    int input = -1;
    while(input != 0){
        std::cout << "type 0 to quit >>";
        std::cin >> input;
    }
    inputBuffer.abort();
    outputBuffer.abort();
    close(stream);
    delete outputChannelSelector;
    delete inputChannelSelector;
    for(int b = 0;b < numberOfBlocks;b++) delete splitFFTedIRs[b];
    delete splitFFTedIRs;
    drwav_uninit(&wav);
    return 0;
}