#include "reco.hpp"

#include "pa_include/portaudio.h"
#include "pa_include/pa_asio.h"
//#include "pa_include/pa_mac_core.h" // Macの場合

#define DR_WAV_IMPLEMENTATION
#include "dr_wav.h"

#include <iostream>


namespace{ // 無名名前空間


/*
PortAudio関連。
*/
void checkError(PaError err){
    if(err != paNoError){
        Pa_Terminate();
        throw std::runtime_error(Pa_GetErrorText(err));
    }
}


/*
PortAudio関連。
*/
void printDeviceInfos(){
    PaError err = Pa_Initialize();
    checkError(err);
    int deviceCount = Pa_GetDeviceCount();
    for(int i = 0;i < deviceCount;i++){
        const PaDeviceInfo* info = Pa_GetDeviceInfo(i);
        std::cout << "[" << i << "]" << std::endl;
        std::cout << info->name << std::endl;
        std::cout << "I/O max channels : " << info->maxInputChannels << " / " << info->maxOutputChannels << "\n" << std::endl;
    }
    Pa_Terminate();
}


/*
PortAudio関連。
*/
PaStream* createNewPaStream(
        int deviceID,
        int* inputChannelSelector,
        int outputNumberOfChannels,
        int* outputChannelSelector,
        int sampleRate,
        int framesPerBuffer,
        PaStreamCallback paStreamCallback,
        void* userData
){
    PaError err = Pa_Initialize();
    checkError(err);
    PaAsioStreamInfo inputAsioInfo;
    inputAsioInfo.size = sizeof(PaAsioStreamInfo);
    inputAsioInfo.hostApiType = paASIO;
    inputAsioInfo.version = 1;
    inputAsioInfo.flags = paAsioUseChannelSelectors;
    inputAsioInfo.channelSelectors = inputChannelSelector;
    PaStreamParameters inputParameters;
    inputParameters.device = deviceID;
    inputParameters.channelCount = 1;
    inputParameters.sampleFormat = paFloat32;
    inputParameters.suggestedLatency = Pa_GetDeviceInfo(deviceID)->defaultLowInputLatency;
    inputParameters.hostApiSpecificStreamInfo = &inputAsioInfo;
    PaAsioStreamInfo outputAsioInfo;
    outputAsioInfo.size = sizeof(PaAsioStreamInfo);
    outputAsioInfo.hostApiType = paASIO;
    outputAsioInfo.version = 1;
    outputAsioInfo.flags = paAsioUseChannelSelectors;
    outputAsioInfo.channelSelectors = outputChannelSelector;
    PaStreamParameters outputParameters;
    outputParameters.device = deviceID;
    outputParameters.channelCount = outputNumberOfChannels;
    outputParameters.sampleFormat = paFloat32;
    outputParameters.suggestedLatency = Pa_GetDeviceInfo(deviceID)->defaultLowOutputLatency;
    outputParameters.hostApiSpecificStreamInfo = &outputAsioInfo;
    PaStream* answer;
    err = Pa_OpenStream(&answer, &inputParameters, &outputParameters, sampleRate, framesPerBuffer, paNoFlag, paStreamCallback, userData);
    checkError(err);
    return answer;
}
// Macの場合
/*
PaStream* createNewPaStream(
        int deviceID,
        int* inputChannelSelector,
        int outputNumberOfChannels,
        int* outputChannelSelector,
        int sampleRate,
        int framesPerBuffer,
        PaStreamCallback paStreamCallback,
        void* userData
){
    PaError err = Pa_Initialize();
    checkError(err);
    PaMacCoreStreamInfo inputCoreInfo;
    inputCoreInfo.size = sizeof(PaMacCoreStreamInfo);
    inputCoreInfo.hostApiType = paCoreAudio;
    inputCoreInfo.version = 1;
    inputCoreInfo.flags = paMacCorePro;
    inputCoreInfo.channelMap = inputChannelSelector;
    inputCoreInfo.channelMapSize = 1;
    PaStreamParameters inputParameters;
    inputParameters.device = 1;
    inputParameters.channelCount = 1;
    inputParameters.sampleFormat = paFloat32;
    inputParameters.suggestedLatency = Pa_GetDeviceInfo(deviceID)->defaultLowInputLatency;
    inputParameters.hostApiSpecificStreamInfo = &inputCoreInfo;
    PaMacCoreStreamInfo outputCoreInfo;
    outputCoreInfo.size = sizeof(PaMacCoreStreamInfo);
    outputCoreInfo.hostApiType = paCoreAudio;
    outputCoreInfo.version = 1;
    outputCoreInfo.flags = paMacCorePro;
    outputCoreInfo.channelMap = outputChannelSelector;
    outputCoreInfo.channelMapSize = outputNumberOfChannels;
    PaStreamParameters outputParameters;
    outputParameters.device = deviceID;
    outputParameters.channelCount = outputNumberOfChannels;
    outputParameters.sampleFormat = paFloat32;
    outputParameters.suggestedLatency = Pa_GetDeviceInfo(deviceID)->defaultLowOutputLatency;
    outputParameters.hostApiSpecificStreamInfo = &outputCoreInfo;
    PaStream* answer;
    err = Pa_OpenStream(&answer, &inputParameters, &outputParameters, sampleRate, framesPerBuffer, paNoFlag, paStreamCallback, userData);
    checkError(err);
    return answer;
}
*/


/*
PortAudio関連。
*/
void start(PaStream* stream){
    PaError err = Pa_StartStream(stream);
    checkError(err);
}


/*
PortAudio関連。
*/
void close(PaStream* stream){
    PaError err = Pa_StopStream(stream);
    checkError(err);
    err = Pa_CloseStream(stream);
    checkError(err);
    Pa_Terminate();
}


typedef struct{
    reco::Convolver* convolver;
    int i;
} CallbackArgs;


int recoCallback(
        const void* inputBufferCallback,
        void* outputBufferCallback,
        unsigned long framesLength,
        const PaStreamCallbackTimeInfo* timeInfo,
        PaStreamCallbackFlags statusFlags,
        void* userData
){    
    CallbackArgs* ca = (CallbackArgs*)userData;
    reco::Convolver* convolver = ca->convolver;
    try{
        convolver->conv((float*)inputBufferCallback, (float*)outputBufferCallback);
    }catch(reco::AbortException& ex){
        return PaStreamCallbackResult::paAbort;
    }
    return PaStreamCallbackResult::paContinue;
}


} // namespace end


int main(){
    constexpr float outputGain = 0.05;
    constexpr int frameLength = 32;
    constexpr int deviceNumber = 2;
    constexpr int numberOfOutputChannels = 2;
    int* inputChannelSelector = new int[1];
    inputChannelSelector[0] = 0;
    int* outputChannelSelector = new int[numberOfOutputChannels];
    for(int i = 0;i < numberOfOutputChannels;i++){
        outputChannelSelector[i] = i;
    }
    constexpr int sampleRate = 48000;
    drwav wav;
    int err = drwav_init_file(&wav, "C:\\Users\\shu\\Desktop\\IR.wav", nullptr);
    if(err == 0) throw std::runtime_error("drwav error");
    if(wav.channels != 1) throw std::runtime_error("must be one channel");
    int irLength = wav.totalPCMFrameCount;
    float* ir = new float[irLength];
    drwav_read_pcm_frames_f32(&wav, irLength, ir);
    float* pulse = new float[irLength]();
    pulse[0] = 1.0;
    for(int i = 0;i < irLength;i++) ir[i] *= outputGain;
    float** irs = new float*[numberOfOutputChannels];
    for(int i = 0;i < numberOfOutputChannels;i++) irs[i] = ir;
    reco::Convolver convolver(numberOfOutputChannels, irLength, irs, frameLength);
    delete[] ir;
    delete[] pulse;
    delete[] irs;
    printDeviceInfos();
    convolver.start();
    CallbackArgs ca;
    ca.convolver = &convolver;
    ca.i = 0;
    PaStream* stream = createNewPaStream(deviceNumber, inputChannelSelector, numberOfOutputChannels, outputChannelSelector, sampleRate, frameLength, recoCallback, &ca);
    start(stream);
    int input = -1;
    while(input != 0){
        std::cout << "type 0 to quit >>";
        std::cin >> input;
    }
    convolver.end();
    close(stream);
    delete[] outputChannelSelector;
    delete[] inputChannelSelector;
    drwav_uninit(&wav);
    return 0;
}