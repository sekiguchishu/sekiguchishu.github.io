/*

    『リアルタイムマルチチャンネル畳み込みライブラリー』
    作者連絡先：@sekiguchi_shu (Twitter)


【依存ライブラリー】

    このコードは，
    Intel Math Kernel Libraryに依存しています。
    ご自身の環境にインストールしてから
    コンパイルしてください。


【コンパイル方法】

    Intel MKLのマニュアルを見ればわかりますが，
    Intel MKLを使用するコードをコンパイルする際，
    コンパイルの前に，コマンドプロンプト上で，
    環境設定用のバッチファイル（mklvars.bat）をよび出す必要があります。

    MKLのインストールフォルダー名は，
    「compilers_and_libraries_2019.5.281」
    のような，バージョン数を含む形式になっており，
    インストールした環境（時期）によって異なります。

    以上を踏まえて，
    Windowsの場合は，
    以下のようなバッチファイルを実行すればよいでしょう。
    デスクトップに，
    「reco.hpp」をインクルードした「main.cpp」が
    あるものとします。

    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    set version=2019.5.281
    cd C:\Program Files (x86)\IntelSWTools\compilers_and_libraries_%version%\windows\mkl\bin
    call mklvars.bat intel64 lp64
    cd C:\Users\shu\Desktop
    g++ -Wall -O2 -o main.exe main.cpp "C:\Program Files (x86)\IntelSWTools\compilers_and_libraries_%version%\windows\mkl\lib\intel64_win\mkl_rt.lib" "C:\Program Files (x86)\IntelSWTools\compilers_and_libraries_%version%\windows\compiler\lib\intel64_win\libiomp5md.lib"
    main.exe
    del main.exe
    pause
    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Macの場合は，
    以下のようなコマンドをターミナルで実行してください。

    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    cd /opt/intel/compilers_and_libraries_2019.5.281/mac/mkl/bin
    source mklvars.sh intel64 lp64
    cd /Users/shu/Desktop
    g++ -std=c++1z -O2 -I${MKLROOT}/include ${MKLROOT}/lib/libmkl_intel_lp64.a ${MKLROOT}/lib/libmkl_intel_thread.a ${MKLROOT}/lib/libmkl_core.a -liomp5 -lpthread -lm -ldl -rpath /opt/intel/compilers_and_libraries_2019.5.281/mac/compiler/lib -o mainexe main.cpp
    ./mainexe
    rm -f mainexe
    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------


【注意点】

    振幅が1.0に正規化された入力信号に，
    振幅が1.0に正規化されたインパルス応答を畳み込むと，
    一般に出力の振幅は1.0を超えます。
    すなわちクリップします。
    そして，どれだけ大きくなるかを
    事前に知ることは不可能，
    すなわち，入力が来てからでないとわからないので，
    IR全体に，1未満の定数をかけておきましょう。
    IRにどの程度のゲインをかけるべきかは，
    IRの各時刻の値や，IRの信号長によって変わりますので，
    テスト信号を入力しながら調整しましょう。


【前提知識】

    オーディオデータを，数十～数百サンプルごとに区切って扱います。
    そのひと区切りを「フレーム」とよびます。
    ところで，同じ時刻の「サンプル」を「チャンネル数」ぶんまとめたものも，
    一般に「フレーム」とよばれます。
    この「フレーム」の2つの用法については，文脈で判断してください。


【使い方】

    まずConvolverクラスのインスタンスを生成します。
    そしてstartをよび出します。
    その後任意の回数convをよび出します。
    終わったらendをよび出します。
    以上の順番でよび出さなかった場合，
    例えばstartをよび出さずにconvをよび出した場合に，
    例外を発生させてプログラマーを保護したりはしていません。
    すなわち動作は未定義です。

    conv関数は，
    オーディオI/Oライブラリーの
    コールバック関数内でよび出されることを想定しており，
    したがって，
    入力を送信すると同時に出力を受け取ります。

    以下，API仕様です。

    クラス：Convolver

    コンストラクター：Convolver(int numberOfOutputChannels, int irLength, float** irsOfAllChannels, int frameLength)

    numberOfOutputChannels：
        出力のチャンネル数。
        入力は1チャンネルで固定。

    irLength：
        IRの，サンプル数での長さ。
        2のべき乗である必要はない。
        全てのIRはこの長さでなければならない。
        各IRの長さが異なる場合，
        最も長いものに合わせて，
        短いものの末尾にゼロ埋めをしてから，
        引数に渡さなければならない。

    irsOfAllChannels：
        各出力チャンネルのIR。
        長さがirLengthであるfloat配列が，
        numberOfOutputChannels個並んだ配列である。
        出力が2チャンネルの場合，
        入力に，irsOfAllChannels[0]を畳み込んだものがLに，
        入力に，irsOfAllChannels[1]を畳み込んだものがRに，
        出力される，という具合である。

    frameLength：
        フレームの長さ。
        2のべき乗でなければならない。
        2のべき乗でない値を指定したときの動作は未定義。
        このアルゴリズムの本質として，
        出力は，入力から，
        フレーム2つぶん遅れる。
        例えばframeLength=64とした場合，
        出力は“最低でも”2.67 ms遅れることになる。
        frameLengthは，
        オーディオデバイスのバッファーサイズと
        揃えたほうがよい場合が多い。

    メンバー関数：void start()
        畳み込み演算をおこなうスレッドを起動する。

    メンバー関数：void end()
        畳み込み演算をおこなうスレッドを終了する。
        endしたあとにもう一度startすることはできない。

    メンバー関数：void conv(float* input, float* output)
        入力を与えて出力を得る。
        inputには，長さがframeLengthである配列を渡す。
        outputには，長さがframeLength * numberOfOutputChannelsである配列を渡す。
        outputの各値は，初期化しておく必要はない。
        outputのすべての値が上書きされる。
        出力は，インターリーブされる。
        すなわち，出力チャンネル数が2，フレーム長が4の場合，
        L_0, R_0, L_1, R_1, L_2, R_2, L_3, R_3
        のように格納される。
        endがよばれたあとにconvがよばれた場合，
        reco::AbortExceptionが発生する。
        コールバックでのconvのよび出しにおいて，
        reco::AbortExceptionをキャッチしておくことで，
        畳み込み処理の終了を，
        オーディオデバイスに知らせることができる。
        オーディオI/OにPortAudioを使っている場合の，
        コールバック関数の擬似コードを以下に示す。
        -------------------------------------------------------------------------------------------------------------
        int callback(.....){
            try{
                convolver->conv((float*)inputBuffer, (float*)outputBuffer);
            }catch(reco::AbortException& ex){
                return PaStreamCallbackResult::paAbort;
            }
            return PaStreamCallbackResult::paContinue;
        }
        -------------------------------------------------------------------------------------------------------------


【論文】

    このソースコードで用いているアルゴリズムは，
    以下の論文を参考にしたものです。
    タイトル：Efficient Convolution without Input-Output Delay
    著者：William G. Gardner
    URL：http://www.cs.ust.hk/mjg_lib/bibs/DPSu/DPSu.Files/Ga95.PDF

*/


#ifndef INCLUDE_GUARD_UUID_BA4690DC_0323_4C12_9751_815A0ADC75E6 // PowerShellのNew-Guidコマンドで生成したUUID
#define INCLUDE_GUARD_UUID_BA4690DC_0323_4C12_9751_815A0ADC75E6


#include <mutex>
#include <condition_variable>
#include <cstring>
#include <thread>


#include "mkl.h"


namespace reco{


/*
％演算子は，
-1 ％ 5
をしたときに-1が返ってしまうが，
周期関数的な用途の剰余演算では，
-1 ％ 5 = 4が返るようにしたい。
そうすれば，負の数を剰余演算した場合でも，
[引数a ]  -5, -4, -3, -2, -1,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, ...
[返り値]   0,  1,  2,  3,  4,  0,  1,  2,  3,  4,  0,  1,  2,  3,  4, ...
のように，周期関数になってくれる。
※ただし，この実装では，bは正であることを想定している。
*/
constexpr int floorMod(int a, int b){
    return (a % b + b) % b;
}


/*
引数のlog2をとり，
それを切り上げた値を返す。
0以下の値が渡されることは想定していない。
*/
constexpr int ceilLog2(int x){
    int counter = 0; // x - 1を2進数で表したときの桁数を数える。
    int xx = x - 1;
    while(xx != 0){ // 正の整数なので右シフトしていくといずれ0になる。そのシフト回数を数える。
        xx >>= 1;
        counter++;
    }
    return counter;
}


/*
分割されたIRブロックの中にフレームが何個入るかを返す関数。

 0 ->  2
 1 ->  1
 2 ->  1
 3 ->  2
 4 ->  2
 5 ->  4
 6 ->  4
 7 ->  8
 8 ->  8
 9 -> 16
10 -> 16
...

を返す。
*/
constexpr int getNumberOfFramesInBlock(int blockNumber){
    if(blockNumber <= 0) return 2;
    int x = (blockNumber - 1) / 2; // 答えが2の何乗かを計算する。
    return 1 << x; // 2のx乗。
}


/*
IR長とフレーム長からIRの分割数を決める。
以下に，フレーム長を1とした場合の，
関数中の各値を示す。
これを見れば法則が分かる。

IR   a   b   c   d   e  ans
 1   *   *   *   *   *   1
 2   *   *   *   *   *   1
 3   1   2   0   0   0   2
 4   2   2   0   1   1   3
 5   3   3   1   0   0   4
 6   4   3   1   1   0   4
 7   5   4   1   2   1   5
 8   6   4   1   3   1   5
 9   7   5   2   0   0   6
10   8   5   2   1   0   6
11   9   6   2   2   0   6
12  10   6   2   3   0   6
13  11   7   2   4   1   7
14  12   7   2   5   1   7
15  13   8   2   6   1   7
16  14   8   2   7   1   7
17  15   9   3   0   0   8
18  16   9   3   1   0   8
19  17  10   3   2   0   8
20  18  10   3   3   0   8
21  19  11   3   4   0   8
22  20  11   3   5   0   8
23  21  12   3   6   0   8
24  22  12   3   7   0   8
25  23  13   3   8   1   9
26  24  13   3   9   1   9
27  25  14   3  10   1   9
28  26  14   3  11   1   9
29  27  15   3  12   1   9
30  28  15   3  13   1   9
31  29  16   3  14   1   9
32  30  16   3  15   1   9
33  31  17   4   0   0  10
...
*/
constexpr int fromIRLengthAndFrameLengthToNumberOfBlocksInIR(int irLength, int frameLength){
    int n = frameLength;
    if(irLength <= 2 * n) return 1;
    int a = irLength - 2 * n;
    int b = (a + 2 * n - 1) / (2 * n) + 1;
    int c = ceilLog2(b) - 1;
    int d = a - ((1 << c) - 1) * 2 * n - 1; // 1 << c は2のc乗
    int e = d / (n * (1 << c));
    return c * 2 + e + 2;
}


/*
複素数配列aとbの要素ごとの掛け算を計算してansに格納する。
*/
void elementwiseTimes(int n, const float* aRe, const float* aIm, const float* bRe, const float* bIm, float* ansRe, float* ansIm){
    for(int i = 0;i < n;i++){
        ansRe[i] = aRe[i] * bRe[i] - aIm[i] * bIm[i];
        ansIm[i] = aRe[i] * bIm[i] + aIm[i] * bRe[i];
    }
}


/*
MKL関連。
ディスクリプターを作る。
*/
void createDescriptor(DFTI_DESCRIPTOR_HANDLE* descriptor, int fftLength){
    DftiCreateDescriptor(descriptor, DFTI_SINGLE, DFTI_COMPLEX, 1, fftLength);
    DftiSetValue(*descriptor, DFTI_PLACEMENT, DFTI_NOT_INPLACE);
    DftiSetValue(*descriptor, DFTI_COMPLEX_STORAGE, DFTI_REAL_REAL);
    DftiSetValue(*descriptor, DFTI_BACKWARD_SCALE, 1.0 / fftLength);
    DftiCommitDescriptor(*descriptor);
}


/*
MKL関連。
ディスクリプターを解放する。
*/
void freeDescriptor(DFTI_DESCRIPTOR_HANDLE* descriptor){
    DftiFreeDescriptor(descriptor);
}


class AbortException : std::exception{};


/*
マイクからの入力をためておくためのバッファー。
あるIRブロックとの畳み込みでは
過去の入力フレームも必要になるので
ためておく必要がある。
バッファーの実装はリングバッファーである。
読み出しを高速にするため，
二重で保存している。
たとえばバッファーが[1, 2, 3, 4]であって，
インデックス2を起点として4つぶん読み出そうとすると，
結果は[3, 4, 1, 2]にならなければならないので，
剰余計算が必要になる
（インデックス2,3,4,5とアクセスすると，
4と5が配列の最大インデックスを超えるので
％4を計算して，2,3,0,1とアクセスしなければならない）。
しかしバッファーへの書き込みの際に二重で書き込んでおく，
すなわち，
[1, 2, 3, 4, 1, 2, 3, 4]
のように保存しておけば，
インデックス2から5までを読み出すだけでよい。
*/
class InputBuffer{
private:
    std::mutex mut;
    std::condition_variable cond;
    bool isAborted;
    int counter; // バッファー内での現在の読み書き位置
    int frameNumberCounterFromOrigin; // 通しフレーム番号を数える
    int frameLength;
    int numberOfFramesInBuffer; // バッファーサイズ
    int bufferLengthInSample; // バッファーのサンプル長さ。実際はこれの2倍である。
    float* array;
public:
    InputBuffer(int frameLength, int numberOfFramesInBuffer):
            isAborted(false),
            counter(0),
            frameNumberCounterFromOrigin(-1),
            frameLength(frameLength),
            numberOfFramesInBuffer(numberOfFramesInBuffer),
            bufferLengthInSample(frameLength * numberOfFramesInBuffer)
    {
        array = new float[bufferLengthInSample * 2]();
    }
    ~InputBuffer(){
        delete array;
    }
    void writeFrame(float* frame) noexcept(false){
        std::unique_lock<std::mutex> lock(mut); // 他スレッドと同期
        if(isAborted) throw AbortException(); // 中断を確認
        int from = counter * frameLength; // 書き込みインデックスを取得
        std::memcpy(array + from, frame, frameLength * sizeof(float));
        std::memcpy(array + (from + bufferLengthInSample), frame, frameLength * sizeof(float)); // 2重で保存
        counter = (counter + 1) % numberOfFramesInBuffer; // カウンターを回す（リングバッファーなので％を使う）
        frameNumberCounterFromOrigin++;
        cond.notify_all(); // マイクからの入力を待機しているスレッドを起こす
    }
    float* getReadPosition(int frameNumberFromOrigin, int numberOfFramesToRead) noexcept(false){
        std::unique_lock<std::mutex> lock(mut);
        while(!isAborted && (frameNumberFromOrigin + numberOfFramesToRead - 1 > frameNumberCounterFromOrigin)){
            cond.wait(lock); // まだ，読み出したいフレームが準備できていなければ待機
        }
        if(isAborted) throw AbortException();
        int indexStart = floorMod(counter - 1 + frameNumberFromOrigin - frameNumberCounterFromOrigin, numberOfFramesInBuffer) * frameLength; // 読み出しインデックスを取得
        return array + indexStart;
    }
    void abort(){ // これのよび出し以降，writeおよびreadでAbortExceptionが投げられる
        std::lock_guard<std::mutex> lock(mut);
        isAborted = true;
        cond.notify_all();
    }
};


/*
計算結果をためておくためのバッファー。
読み書きはキュー形式である。
*/
class OutputBuffer{
private:
    std::mutex mut;
    bool isAborted;
    int* front; // キューの先頭位置（モジュロは取らずにカウントしていく）
    int back; // キューの末尾位置（モジュロは取らずにカウントしていく）
    float** array;
    int queueCapacity;
    int maxNf;
    int frameLength;
    int numberOfOutputChannels;
    int numberOfBlocksInIR;
public:
    OutputBuffer(int frameLength, int numberOfOutputChannels, int numberOfBlocksInIR):
            isAborted(false),
            back(-1),
            queueCapacity(8),
            maxNf(getNumberOfFramesInBlock(std::max(3, numberOfBlocksInIR - 1))),
            frameLength(frameLength),
            numberOfOutputChannels(numberOfOutputChannels),
            numberOfBlocksInIR(numberOfBlocksInIR)
    {
        front = new int[numberOfBlocksInIR];
        front[0] = -1;
        for(int b = 1;b < numberOfBlocksInIR;b++){
            int nf = getNumberOfFramesInBlock(b);
            if(b % 2 == 1){
                front[b] = 2 * nf - 1;
            }else{
                front[b] = 3 * nf - 1;
            }
        }
        array = new float*[numberOfBlocksInIR];
        for(int b = 0;b < numberOfBlocksInIR;b++){
            array[b] = new float[numberOfOutputChannels * queueCapacity * frameLength * maxNf]();
        }
    }
    ~OutputBuffer(){
        for(int b = 0;b < numberOfBlocksInIR;b++){
            delete array[b];
        }
        delete array;
        delete front;
    }
    void writeBlock(int blockNumber, float* conv) noexcept(false){
        if(isAborted) throw AbortException();
        int b = blockNumber;
        int nf = getNumberOfFramesInBlock(b);
        int writeFramePosition = (front[b] + 1) % (queueCapacity * maxNf);
        int writePosition = writeFramePosition * frameLength * numberOfOutputChannels;
        for(int f = 0;f < nf;f++){
            for(int i = 0;i < frameLength;i++){
                for(int c = 0;c < numberOfOutputChannels;c++){
                    (array[b] + writePosition)[f * frameLength * numberOfOutputChannels + i * numberOfOutputChannels + c] = conv[frameLength * nf * 2 * c + frameLength * f + i];
                }
            }
        }
        front[b] += nf;
    }
    bool isEmpty(){
        for(int b = 0;b < numberOfBlocksInIR;b++){
            if(front[b] - back == 0) return true;
        }
        return false;
    }
    void copyToAnswer(int frameNumberFromOrigin, float* answer) noexcept(false){
        std::unique_lock<std::mutex> lock(mut);
        while(!isAborted && isEmpty()); // あえてビジーウェイトにしている
        if(isAborted) throw AbortException();
        if(frameNumberFromOrigin - 1 == back) back++;
        int readFramePosition = floorMod(frameNumberFromOrigin, queueCapacity * maxNf);
        int readPosition = readFramePosition * frameLength * numberOfOutputChannels;
        std::memset(answer, 0, sizeof(float) * frameLength * numberOfOutputChannels);
        for(int b = 0;b < numberOfBlocksInIR;b++){
            for(int t = 0;t < frameLength * numberOfOutputChannels;t++){
                answer[t] += (array[b] + readPosition)[t];
            }
        }
    }
    void abort(){
        std::lock_guard<std::mutex> lock(mut);
        isAborted = true;
    }
};


void thread0(InputBuffer* inputBuffer, OutputBuffer* outputBuffer, int numberOfOutputChannels, int frameLength, float** splitFFTedIRs, int threadNumber){
    constexpr int b = 0;
    constexpr int nf = getNumberOfFramesInBlock(b);
    int fftLength = frameLength * nf * 2;
    DFTI_DESCRIPTOR_HANDLE descriptor;
    createDescriptor(&descriptor, fftLength);
    float* zeros = new float[fftLength]();
    float* xFFT = new float[fftLength * 2];
    float* times = new float[fftLength * 2 * numberOfOutputChannels];
    float* dummy = new float[fftLength];
    float* conv = new float[fftLength * numberOfOutputChannels];
    for(int start = 0;true;start += nf){
        try{
            float* xBlock = inputBuffer->getReadPosition(start - nf, nf * 2);
            DftiComputeForward(descriptor, xBlock, zeros, xFFT, xFFT + fftLength);
            for(int c = 0;c < numberOfOutputChannels;c++){
                elementwiseTimes(
                        fftLength,
                        xFFT,
                        xFFT + fftLength,
                        splitFFTedIRs[b] + (fftLength * 2 * c),
                        splitFFTedIRs[b] + (fftLength * 2 * c + fftLength),
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength)
                );
                DftiComputeBackward(
                        descriptor,
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength),
                        conv + (fftLength * c),
                        dummy
                );
            }
            outputBuffer->writeBlock(b, conv);
        }catch(AbortException& ex){
            break;
        }
    }
    delete[] conv;
    delete[] dummy;
    delete[] times;
    delete[] xFFT;
    delete[] zeros;
    freeDescriptor(&descriptor);
}


void threadi(InputBuffer* inputBuffer, OutputBuffer* outputBuffer, int numberOfOutputChannels, int frameLength, float** splitFFTedIRs, int threadNumber){
    int b1 = threadNumber * 2;
    int b0 = b1 - 1;
    int nf = getNumberOfFramesInBlock(b0);
    int fftLength = frameLength * nf * 2;
    DFTI_DESCRIPTOR_HANDLE descriptor;
    createDescriptor(&descriptor, fftLength);
    float* zeros = new float[fftLength]();
    float* xFFT = new float[fftLength * 2];
    float* times = new float[fftLength * 2 * numberOfOutputChannels];
    float* dummy = new float[fftLength];
    float* conv = new float[fftLength * numberOfOutputChannels];
    for(int start = 0;true;start += nf){
        try{
            float* xBlock = inputBuffer->getReadPosition(start - nf, nf * 2);
            DftiComputeForward(descriptor, xBlock, zeros, xFFT, xFFT + fftLength);
            for(int c = 0;c < numberOfOutputChannels;c++){
                elementwiseTimes(
                        fftLength,
                        xFFT,
                        xFFT + fftLength,
                        splitFFTedIRs[b0] + (fftLength * 2 * c),
                        splitFFTedIRs[b0] + (fftLength * 2 * c + fftLength),
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength)
                );
                DftiComputeBackward(
                        descriptor,
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength),
                        conv + (fftLength * c),
                        dummy
                );
            }
            outputBuffer->writeBlock(b0, conv);
            for(int c = 0;c < numberOfOutputChannels;c++){
                elementwiseTimes(
                        fftLength,
                        xFFT,
                        xFFT + fftLength,
                        splitFFTedIRs[b1] + (fftLength * 2 * c),
                        splitFFTedIRs[b1] + (fftLength * 2 * c + fftLength),
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength)
                );
                DftiComputeBackward(
                        descriptor,
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength),
                        conv + (fftLength * c),
                        dummy
                );
            }
            outputBuffer->writeBlock(b1, conv);
        }catch(AbortException& ex){
            break;
        }
    }
    delete[] conv;
    delete[] dummy;
    delete[] times;
    delete[] xFFT;
    delete[] zeros;
    freeDescriptor(&descriptor);
}


void threadLastHalf(InputBuffer* inputBuffer, OutputBuffer* outputBuffer, int numberOfOutputChannels, int frameLength, float** splitFFTedIRs, int threadNumber){
    int b0 = threadNumber * 2 - 1;
    int nf = getNumberOfFramesInBlock(b0);
    int fftLength = frameLength * nf * 2;
    DFTI_DESCRIPTOR_HANDLE descriptor;
    createDescriptor(&descriptor, fftLength);
    float* zeros = new float[fftLength]();
    float* xFFT = new float[fftLength * 2];
    float* times = new float[fftLength * 2 * numberOfOutputChannels];
    float* dummy = new float[fftLength];
    float* conv = new float[fftLength * numberOfOutputChannels];
    for(int start = 0;true;start += nf){
        try{
            float* xBlock = inputBuffer->getReadPosition(start - nf, nf * 2);
            DftiComputeForward(descriptor, xBlock, zeros, xFFT, xFFT + fftLength);
            for(int c = 0;c < numberOfOutputChannels;c++){
                elementwiseTimes(
                        fftLength,
                        xFFT,
                        xFFT + fftLength,
                        splitFFTedIRs[b0] + (fftLength * 2 * c),
                        splitFFTedIRs[b0] + (fftLength * 2 * c + fftLength),
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength)
                );
                DftiComputeBackward(
                        descriptor,
                        times + (fftLength * 2 * c),
                        times + (fftLength * 2 * c + fftLength),
                        conv + (fftLength * c),
                        dummy
                );
                outputBuffer->writeBlock(b0, conv);
            }
        }catch(AbortException& ex){
            break;
        }
    }
    delete[] conv;
    delete[] dummy;
    delete[] times;
    delete[] xFFT;
    delete[] zeros;
    freeDescriptor(&descriptor);
}


/*
まずインパルス応答を
2N, N, N, 2N, 2N, 4N, 4N, 8N, 8N, 16N, 16N, ...
のように区切る。
インパルス応答が最後のブロックの最後まで満たなかった場合，
0が付加される。
次に，
各ブロックの先頭にブロック長と同じ長さだけ0を付加（ブロック長は2倍となる）し，
それらをFFTする。
frameLengthは2のべき乗でなければならない。
*/
void splitIRAndFFT(
        int numberOfOutputChannels,
        int irLength,
        float** ir, // 出力チャンネル分のIR
        int frameLength,
        float*** answer
){
    int numberOfBlocks = fromIRLengthAndFrameLengthToNumberOfBlocksInIR(irLength, frameLength);
    int cumsum = 0;
    *answer = new float*[numberOfBlocks];
    for(int b = 0;b < numberOfBlocks;b++){
        int blockLength = getNumberOfFramesInBlock(b) * frameLength;
        int fftLength = blockLength * 2;
        float* fft = new float[fftLength * 2 * numberOfOutputChannels]();
        for(int c = 0;c < numberOfOutputChannels;c++){
            float* temp = new float[fftLength]();
            std::memcpy(temp + blockLength, ir[c] + cumsum, sizeof(float) * std::min(blockLength, irLength - cumsum));
            float* zeros = new float[fftLength]();
            DFTI_DESCRIPTOR_HANDLE descriptor;
            createDescriptor(&descriptor, fftLength);
            DftiComputeForward(descriptor, temp, zeros, fft + (fftLength * 2 * c), fft + (fftLength * 2 * c + fftLength));
            freeDescriptor(&descriptor);
            delete[] zeros;
            delete[] temp;
        }
        (*answer)[b] = fft;
        cumsum += blockLength;
    }
}


class Convolver{
private:
    int numberOfOutputChannels;
    int frameLength;
    float** splitFFTedIRs;
    int numberOfBlocks;
    int delay;
    int outputFrameNumberFromOrigin;
    InputBuffer* inputBuffer;
    OutputBuffer* outputBuffer;
public:
    Convolver(int numberOfOutputChannels, int irLength, float** irsOfAllChannels, int frameLength){
        this->numberOfOutputChannels = numberOfOutputChannels;
        this->frameLength = frameLength;
        delay = 2;
        outputFrameNumberFromOrigin = 0;
        numberOfBlocks = fromIRLengthAndFrameLengthToNumberOfBlocksInIR(irLength, frameLength);
        splitIRAndFFT(numberOfOutputChannels, irLength, irsOfAllChannels, frameLength, &splitFFTedIRs);
        int bMax = std::max(3, numberOfBlocks - 1);
        int nfMax = getNumberOfFramesInBlock(bMax);
        inputBuffer = new InputBuffer(frameLength, nfMax * 2);
        float* tempZeros = new float[frameLength]();
        for(int i = 0;i < delay;i++) inputBuffer->writeFrame(tempZeros);
        delete[] tempZeros;
        outputBuffer = new OutputBuffer(frameLength, numberOfOutputChannels, numberOfBlocks);
    }
    ~Convolver(){
        for(int b = 0;b < numberOfBlocks;b++) delete[] splitFFTedIRs[b];
        delete[] splitFFTedIRs;
        delete inputBuffer;
        delete outputBuffer;
    }
    void start(){
        int numberOfThreads = numberOfBlocks / 2 + 1;
        std::thread t0(thread0, inputBuffer, outputBuffer, numberOfOutputChannels, frameLength, splitFFTedIRs, 0);
        t0.detach();
        for(int i = 1;i < numberOfThreads - 1;i++){
            std::thread ti(threadi, inputBuffer, outputBuffer, numberOfOutputChannels, frameLength, splitFFTedIRs, i);
            ti.detach();
        }
        if(numberOfThreads >= 2){
            if(numberOfBlocks % 2 == 0){
                std::thread tl(threadLastHalf, inputBuffer, outputBuffer, numberOfOutputChannels, frameLength, splitFFTedIRs, numberOfThreads - 1);
                tl.detach();
            }else{
                std::thread tl(threadi, inputBuffer, outputBuffer, numberOfOutputChannels, frameLength, splitFFTedIRs, numberOfThreads - 1);
                tl.detach();
            }
        }
    }
    void end(){
        inputBuffer->abort();
        outputBuffer->abort();
    }
    void conv(float* input, float* output) noexcept(false){
        inputBuffer->writeFrame(input);
        outputBuffer->copyToAnswer(outputFrameNumberFromOrigin, output);
        outputFrameNumberFromOrigin++;
    }
}; // class Convolver


} // namespace reco


#endif // ifndef INCLUDE_GUARD_UUID_BA4690DC_0323_4C12_9751_815A0ADC75E6