cd /opt/intel/compilers_and_libraries_2019.5.281/mac/mkl/bin
source mklvars.sh intel64 lp64
cd /Users/shu/Desktop/reco
g++ -std=c++17 -O2 -I${MKLROOT}/include ${MKLROOT}/lib/libmkl_intel_lp64.a ${MKLROOT}/lib/libmkl_intel_thread.a ${MKLROOT}/lib/libmkl_core.a -liomp5 -lpthread -lm -ldl -rpath /opt/intel/compilers_and_libraries_2019.5.281/mac/compiler/lib -o recoexe reco_pa_mac.cpp libportaudio.dylib
./recoexe